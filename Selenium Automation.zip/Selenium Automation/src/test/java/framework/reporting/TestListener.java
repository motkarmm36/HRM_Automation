package framework.reporting;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import framework.base.DriverFactory;
import framework.utils.ScreenshotUtils;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class TestListener implements ITestListener {
    private static final ExtentReports REPORTER = ExtentManager.getReporter();
    private static final ThreadLocal<ExtentTest> TEST_LOG = new ThreadLocal<>();

    @Override
    public void onStart(ITestContext context) {
        REPORTER.setSystemInfo("Suite", context.getSuite().getName());
    }

    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest test = REPORTER.createTest(result.getMethod().getMethodName());
        TEST_LOG.set(test);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        TEST_LOG.get().pass("Test passed");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        ExtentTest test = TEST_LOG.get();
        if (result.getThrowable() != null) {
            test.fail(result.getThrowable());
        }

        if (hasActiveDriver()) {
            String screenshotPath = ScreenshotUtils.capture(result.getMethod().getMethodName());
            test.addScreenCaptureFromPath(screenshotPath);
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        TEST_LOG.get().skip("Test skipped");
    }

    @Override
    public void onFinish(ITestContext context) {
        REPORTER.flush();
        TEST_LOG.remove();
    }

    private boolean hasActiveDriver() {
        try {
            DriverFactory.getDriver();
            return true;
        } catch (IllegalStateException exception) {
            return false;
        }
    }
}
