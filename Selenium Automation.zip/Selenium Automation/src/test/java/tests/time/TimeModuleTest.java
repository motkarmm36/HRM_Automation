package tests.time;

import framework.base.BaseTest;
import framework.pages.LoginPage;
import framework.pages.TimePage;
import framework.reporting.TestListener;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(TestListener.class)
public class TimeModuleTest extends BaseTest {

    @Test(description = "Time module: search employee timesheet.")
    public void verifySearchEmployeeTimesheet() {
        loginAsAdmin();

        TimePage timePage = new TimePage(driver).open();
        timePage.searchEmployeeTimesheet("a");
        Assert.assertTrue(timePage.isTimesheetVisible(), "Timesheet page or no-record message should be visible.");
    }

    private void loginAsAdmin() {
        new LoginPage(driver).waitUntilLoaded().loginWithValidCredentials("Admin", "admin123").waitUntilLoaded();
    }
}
