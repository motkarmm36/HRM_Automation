package tests.leave;

import framework.base.BaseTest;
import framework.pages.LeavePage;
import framework.pages.LoginPage;
import framework.reporting.TestListener;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(TestListener.class)
public class LeaveModuleTest extends BaseTest {

    @Test(description = "Leave module: search leave list, apply leave and verify my leave.")
    public void verifyLeaveModuleFlows() {
        loginAsAdmin();

        LeavePage leavePage = new LeavePage(driver).open();
        leavePage.searchLeaveList();
        Assert.assertTrue(leavePage.isLeaveListRendered(), "Leave list should render after search.");

        leavePage.applyLeave("Automated leave request from framework test.");
        Assert.assertTrue(leavePage.isLeaveApplyAttemptProcessed(),
                "Leave apply action should be processed with success or warning message.");

        leavePage.openMyLeaveAndSearch();
        Assert.assertTrue(leavePage.isOnMyLeavePage(), "User should be able to navigate and search in My Leave page.");
    }

    private void loginAsAdmin() {
        new LoginPage(driver).waitUntilLoaded().loginWithValidCredentials("Admin", "admin123").waitUntilLoaded();
    }
}
