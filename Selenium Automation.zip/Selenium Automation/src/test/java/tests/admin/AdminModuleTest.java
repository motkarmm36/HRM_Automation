package tests.admin;

import framework.base.BaseTest;
import framework.pages.AdminPage;
import framework.pages.LoginPage;
import framework.reporting.TestListener;
import framework.utils.TestDataFactory;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(TestListener.class)
public class AdminModuleTest extends BaseTest {

    @Test(description = "Admin module: add user and search for added user.")
    public void verifyAddAndSearchUserInAdminModule() {
        loginAsAdmin();

        String username = TestDataFactory.uniqueUsername("adminUser");
        String password = TestDataFactory.defaultPassword();

        AdminPage adminPage = new AdminPage(driver).open();
        adminPage.addUser("a", username, password)
                .open()
                .searchUser(username);

        Assert.assertTrue(adminPage.isUserPresentInResults(username),
                "Newly added admin user should appear in search results.");
    }

    private void loginAsAdmin() {
        new LoginPage(driver).waitUntilLoaded().loginWithValidCredentials("Admin", "admin123").waitUntilLoaded();
    }
}
