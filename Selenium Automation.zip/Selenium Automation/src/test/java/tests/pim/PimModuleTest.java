package tests.pim;

import framework.base.BaseTest;
import framework.pages.LoginPage;
import framework.pages.PimPage;
import framework.reporting.TestListener;
import framework.utils.TestDataFactory;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(TestListener.class)
public class PimModuleTest extends BaseTest {

    @Test(description = "PIM module: add employee and search the employee.")
    public void verifyAddAndSearchEmployeeInPimModule() {
        loginAsAdmin();

        PimPage pimPage = new PimPage(driver).open();
        String employeeId = pimPage.addEmployee(
                TestDataFactory.uniqueFirstName(),
                TestDataFactory.uniqueLastName()
        );

        pimPage.goToEmployeeList()
                .searchByEmployeeId(employeeId);

        Assert.assertTrue(pimPage.isEmployeePresentInResults(employeeId),
                "Added employee should appear in PIM employee list search.");
    }

    private void loginAsAdmin() {
        new LoginPage(driver).waitUntilLoaded().loginWithValidCredentials("Admin", "admin123").waitUntilLoaded();
    }
}
