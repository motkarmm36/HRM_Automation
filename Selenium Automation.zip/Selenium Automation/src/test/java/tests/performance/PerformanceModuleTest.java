package tests.performance;

import framework.base.BaseTest;
import framework.pages.LoginPage;
import framework.pages.PerformancePage;
import framework.reporting.TestListener;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(TestListener.class)
public class PerformanceModuleTest extends BaseTest {

    @Test(description = "Performance module: search KPI records.")
    public void verifySearchKpi() {
        loginAsAdmin();

        PerformancePage performancePage = new PerformancePage(driver).open();
        performancePage.searchKpis();
        Assert.assertTrue(performancePage.isKpiSearchResultRendered(),
                "KPI table or no-record state should render after KPI search.");
    }

    private void loginAsAdmin() {
        new LoginPage(driver).waitUntilLoaded().loginWithValidCredentials("Admin", "admin123").waitUntilLoaded();
    }
}
