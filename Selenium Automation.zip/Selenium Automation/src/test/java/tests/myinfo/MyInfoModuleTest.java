package tests.myinfo;

import framework.base.BaseTest;
import framework.pages.LoginPage;
import framework.pages.MyInfoPage;
import framework.reporting.TestListener;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(TestListener.class)
public class MyInfoModuleTest extends BaseTest {

    @Test(description = "My Info module: view personal details.")
    public void verifyViewMyInfo() {
        loginAsAdmin();

        MyInfoPage myInfoPage = new MyInfoPage(driver).open();
        Assert.assertTrue(myInfoPage.isMyInfoVisible(), "Personal details should be visible in My Info module.");
    }

    private void loginAsAdmin() {
        new LoginPage(driver).waitUntilLoaded().loginWithValidCredentials("Admin", "admin123").waitUntilLoaded();
    }
}
