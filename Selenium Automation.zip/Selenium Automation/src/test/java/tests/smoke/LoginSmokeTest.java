package tests.smoke;

import framework.base.BaseTest;
import framework.pages.DashboardPage;
import framework.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import framework.reporting.TestListener;

@Listeners(TestListener.class)
public class LoginSmokeTest extends BaseTest {

    @Test(description = "Verify valid user can login, view dashboard and logout.")
    public void verifyLoginDashboardAndLogoutFlow() {
        LoginPage loginPage = new LoginPage(driver).waitUntilLoaded();

        DashboardPage dashboardPage = loginPage.loginWithValidCredentials("Admin", "admin123")
                .waitUntilLoaded();

        Assert.assertTrue(dashboardPage.isLoaded(), "Dashboard should be visible after successful login.");

        LoginPage postLogoutLoginPage = dashboardPage.logout().waitUntilLoaded();
        Assert.assertTrue(postLogoutLoginPage.isAtLoginPage(), "User should be redirected to login after logout.");
    }
}
