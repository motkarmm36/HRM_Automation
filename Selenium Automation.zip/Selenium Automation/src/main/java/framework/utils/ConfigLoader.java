package framework.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class ConfigLoader {
    private static final String CONFIG_PATH = "config/config.properties";
    private static final Properties PROPERTIES = new Properties();
    private static volatile boolean loaded;

    private ConfigLoader() {
    }

    private static void loadPropertiesIfRequired() {
        if (loaded) {
            return;
        }

        synchronized (ConfigLoader.class) {
            if (loaded) {
                return;
            }
            try (InputStream inputStream = ConfigLoader.class.getClassLoader().getResourceAsStream(CONFIG_PATH)) {
                if (inputStream == null) {
                    throw new IllegalStateException("Unable to find configuration file: " + CONFIG_PATH);
                }
                PROPERTIES.load(inputStream);
                loaded = true;
            } catch (IOException exception) {
                throw new IllegalStateException("Unable to load configuration file: " + CONFIG_PATH, exception);
            }
        }
    }

    public static String get(String key) {
        loadPropertiesIfRequired();
        String systemValue = System.getProperty(key);
        if (systemValue != null && !systemValue.isBlank()) {
            return systemValue.trim();
        }

        String propertyValue = PROPERTIES.getProperty(key);
        if (propertyValue == null) {
            throw new IllegalArgumentException("Missing required configuration key: " + key);
        }
        return propertyValue.trim();
    }

    public static int getInt(String key) {
        return Integer.parseInt(get(key));
    }

    public static boolean getBoolean(String key) {
        return Boolean.parseBoolean(get(key));
    }
}
