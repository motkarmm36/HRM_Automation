package framework.utils;

import framework.base.DriverFactory;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class ScreenshotUtils {
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");
    private static final Path OUTPUT_DIRECTORY = Paths.get("test-output", "screenshots");

    private ScreenshotUtils() {
    }

    public static String capture(String testName) {
        try {
            Files.createDirectories(OUTPUT_DIRECTORY);
            String fileName = testName + "_" + DATE_TIME_FORMATTER.format(LocalDateTime.now()) + ".png";
            Path targetPath = OUTPUT_DIRECTORY.resolve(fileName);

            File sourceFile = ((TakesScreenshot) DriverFactory.getDriver()).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(sourceFile, targetPath.toFile());
            return targetPath.toString();
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to capture screenshot for test: " + testName, exception);
        }
    }
}
