package framework.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ThreadLocalRandom;

public final class TestDataFactory {
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("MMddHHmmss");

    private TestDataFactory() {
    }

    public static String uniqueUsername(String prefix) {
        return prefix + "_" + DATE_TIME_FORMATTER.format(LocalDateTime.now());
    }

    public static String uniqueFirstName() {
        return "FN" + randomAlpha(5);
    }

    public static String uniqueLastName() {
        return "LN" + randomAlpha(6);
    }

    public static String defaultPassword() {
        return "Orange@123";
    }

    private static String randomAlpha(int length) {
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder builder = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int randomIndex = ThreadLocalRandom.current().nextInt(alphabet.length());
            builder.append(alphabet.charAt(randomIndex));
        }
        return builder.toString();
    }
}
