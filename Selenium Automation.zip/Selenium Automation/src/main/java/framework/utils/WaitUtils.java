package framework.utils;

import framework.base.DriverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public final class WaitUtils {
    private WaitUtils() {
    }

    private static WebDriverWait defaultWait() {
        return new WebDriverWait(
                DriverFactory.getDriver(),
                Duration.ofSeconds(ConfigLoader.getInt("explicitWaitInSeconds"))
        );
    }

    public static WebElement waitForVisibility(By locator) {
        return defaultWait().until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public static WebElement waitForClickable(By locator) {
        return defaultWait().until(ExpectedConditions.elementToBeClickable(locator));
    }

    public static boolean waitForUrlContains(String expectedText) {
        return defaultWait().until(ExpectedConditions.urlContains(expectedText));
    }

    public static boolean waitForInvisibility(By locator) {
        return defaultWait().until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }
}
