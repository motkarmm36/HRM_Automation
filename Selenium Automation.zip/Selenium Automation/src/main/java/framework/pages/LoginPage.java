package framework.pages;

import framework.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    private final WebDriver driver;

    private static final By USERNAME_INPUT = By.name("username");
    private static final By PASSWORD_INPUT = By.name("password");
    private static final By LOGIN_BUTTON = By.cssSelector("button[type='submit']");
    private static final By LOGIN_FORM = By.cssSelector("form.oxd-form");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public LoginPage waitUntilLoaded() {
        WaitUtils.waitForVisibility(LOGIN_FORM);
        WaitUtils.waitForVisibility(USERNAME_INPUT);
        WaitUtils.waitForVisibility(PASSWORD_INPUT);
        return this;
    }

    public DashboardPage loginWithValidCredentials(String username, String password) {
        WaitUtils.waitForVisibility(USERNAME_INPUT).clear();
        WaitUtils.waitForVisibility(USERNAME_INPUT).sendKeys(username);
        WaitUtils.waitForVisibility(PASSWORD_INPUT).clear();
        WaitUtils.waitForVisibility(PASSWORD_INPUT).sendKeys(password);
        WaitUtils.waitForClickable(LOGIN_BUTTON).click();
        return new DashboardPage(driver);
    }

    public boolean isAtLoginPage() {
        return WaitUtils.waitForUrlContains("/auth/login") && WaitUtils.waitForVisibility(LOGIN_BUTTON).isDisplayed();
    }
}
