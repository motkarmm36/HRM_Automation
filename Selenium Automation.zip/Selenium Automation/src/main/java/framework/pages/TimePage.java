package framework.pages;

import framework.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;

public class TimePage {
    private final WebDriver driver;

    private static final By TIME_MENU = By.xpath("//span[normalize-space()='Time']");
    private static final By EMPLOYEE_NAME_INPUT = By.xpath("//label[normalize-space()='Employee Name']/ancestor::div[contains(@class,'oxd-input-group')]//input");
    private static final By VIEW_BUTTON = By.xpath("//button[@type='submit']");

    public TimePage(WebDriver driver) {
        this.driver = driver;
    }

    public TimePage open() {
        WaitUtils.waitForClickable(TIME_MENU).click();
        WaitUtils.waitForUrlContains("/time");
        return this;
    }

    public TimePage searchEmployeeTimesheet(String employeeName) {
        WaitUtils.waitForVisibility(EMPLOYEE_NAME_INPUT).sendKeys(employeeName);
        By suggestion = By.xpath("(//div[@role='listbox']//span)[1]");
        WaitUtils.waitForClickable(suggestion).click();
        WaitUtils.waitForClickable(VIEW_BUTTON).click();
        return this;
    }

    public boolean isTimesheetVisible() {
        By timesheetHeader = By.xpath("//h6[contains(normalize-space(),'Timesheet')]");
        try {
            return WaitUtils.waitForVisibility(timesheetHeader).isDisplayed();
        } catch (TimeoutException exception) {
            By noRecords = By.xpath("//span[normalize-space()='No Records Found']");
            return !driver.findElements(noRecords).isEmpty();
        }
    }
}
