package framework.pages;

import framework.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;

public class PerformancePage {
    private final WebDriver driver;

    private static final By PERFORMANCE_MENU = By.xpath("//span[normalize-space()='Performance']");
    private static final By CONFIGURE_TAB = By.xpath("//span[normalize-space()='Configure']");
    private static final By KPI_TAB = By.xpath("//a[normalize-space()='KPIs']");
    private static final By SEARCH_BUTTON = By.xpath("//button[@type='submit']");

    public PerformancePage(WebDriver driver) {
        this.driver = driver;
    }

    public PerformancePage open() {
        WaitUtils.waitForClickable(PERFORMANCE_MENU).click();
        WaitUtils.waitForUrlContains("/performance");
        return this;
    }

    public PerformancePage searchKpis() {
        WaitUtils.waitForClickable(CONFIGURE_TAB).click();
        WaitUtils.waitForClickable(KPI_TAB).click();
        WaitUtils.waitForClickable(SEARCH_BUTTON).click();
        return this;
    }

    public boolean isKpiSearchResultRendered() {
        By kpiTable = By.cssSelector(".oxd-table-body");
        try {
            return WaitUtils.waitForVisibility(kpiTable).isDisplayed();
        } catch (TimeoutException exception) {
            By noRecords = By.xpath("//span[normalize-space()='No Records Found']");
            return !driver.findElements(noRecords).isEmpty();
        }
    }
}
