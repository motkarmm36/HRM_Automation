package framework.pages;

import framework.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class AdminPage {
    private final WebDriver driver;

    private static final By ADMIN_MENU = By.xpath("//span[normalize-space()='Admin']");
    private static final By ADD_BUTTON = By.xpath("//button[normalize-space()='Add']");
    private static final By SAVE_BUTTON = By.xpath("//button[@type='submit' and normalize-space()='Save']");
    private static final By SEARCH_BUTTON = By.xpath("//button[@type='submit' and normalize-space()='Search']");
    private static final By SUCCESS_TOAST = By.xpath("//div[contains(@class,'oxd-toast--success')]");

    public AdminPage(WebDriver driver) {
        this.driver = driver;
    }

    public AdminPage open() {
        WaitUtils.waitForClickable(ADMIN_MENU).click();
        WaitUtils.waitForUrlContains("/admin");
        return this;
    }

    public AdminPage addUser(String employeeName, String username, String password) {
        WaitUtils.waitForClickable(ADD_BUTTON).click();
        selectDropdownByLabel("User Role", "Admin");
        selectEmployeeName(employeeName);
        typeInputByLabel("Username", username);
        selectDropdownByLabel("Status", "Enabled");
        typeInputByLabel("Password", password);
        typeInputByLabel("Confirm Password", password);
        WaitUtils.waitForClickable(SAVE_BUTTON).click();
        WaitUtils.waitForVisibility(SUCCESS_TOAST);
        return this;
    }

    public AdminPage searchUser(String username) {
        typeInputByLabel("Username", username);
        WaitUtils.waitForClickable(SEARCH_BUTTON).click();
        return this;
    }

    public boolean isUserPresentInResults(String username) {
        By userCell = By.xpath("//div[contains(@class,'oxd-table-cell')]/div[normalize-space()='" + username + "']");
        try {
            return WaitUtils.waitForVisibility(userCell).isDisplayed();
        } catch (TimeoutException exception) {
            return false;
        }
    }

    private void selectEmployeeName(String employeeName) {
        By employeeInput = inputByLabel("Employee Name");
        WaitUtils.waitForVisibility(employeeInput).sendKeys(employeeName);
        By option = By.xpath("//div[@role='listbox']//span[contains(normalize-space(),'" + employeeName + "')]");
        WaitUtils.waitForClickable(option).click();
    }

    private void selectDropdownByLabel(String label, String value) {
        By dropdown = By.xpath("//label[normalize-space()='" + label
                + "']/ancestor::div[contains(@class,'oxd-input-group')]//div[contains(@class,'oxd-select-text-input')]");
        WaitUtils.waitForClickable(dropdown).click();

        List<WebElement> matchingOptions = driver.findElements(By.xpath("//div[@role='listbox']//span[normalize-space()='"
                + value + "']"));
        if (!matchingOptions.isEmpty()) {
            matchingOptions.get(0).click();
            return;
        }
        WaitUtils.waitForClickable(By.xpath("//div[@role='listbox']//span[normalize-space()='" + value + "']")).click();
    }

    private void typeInputByLabel(String label, String value) {
        By input = inputByLabel(label);
        WebElement element = WaitUtils.waitForVisibility(input);
        element.clear();
        element.sendKeys(value);
    }

    private By inputByLabel(String label) {
        return By.xpath("//label[normalize-space()='" + label
                + "']/ancestor::div[contains(@class,'oxd-input-group')]//input");
    }
}
