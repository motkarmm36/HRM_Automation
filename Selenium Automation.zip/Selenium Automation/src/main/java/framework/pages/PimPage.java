package framework.pages;

import framework.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PimPage {
    private final WebDriver driver;
    private String lastAddedEmployeeName;

    private static final By PIM_MENU = By.xpath("//span[normalize-space()='PIM']");
    private static final By ADD_BUTTON = By.xpath("//button[normalize-space()='Add']");
    private static final By FIRST_NAME_INPUT = By.name("firstName");
    private static final By LAST_NAME_INPUT = By.name("lastName");
    private static final By SAVE_BUTTON = By.xpath("//button[@type='submit' and normalize-space()='Save']");
    private static final By PERSONAL_DETAILS_HEADER = By.xpath("//h6[normalize-space()='Personal Details']");
    private static final By EMPLOYEE_LIST_TAB = By.xpath("//a[normalize-space()='Employee List']");
    private static final By SEARCH_BUTTON = By.xpath("//button[@type='submit' and normalize-space()='Search']");

    public PimPage(WebDriver driver) {
        this.driver = driver;
    }

    public PimPage open() {
        WaitUtils.waitForClickable(PIM_MENU).click();
        WaitUtils.waitForUrlContains("/pim");
        return this;
    }

    public String addEmployee(String firstName, String lastName) {
        WaitUtils.waitForClickable(ADD_BUTTON).click();
        WaitUtils.waitForVisibility(FIRST_NAME_INPUT).sendKeys(firstName);
        WaitUtils.waitForVisibility(LAST_NAME_INPUT).sendKeys(lastName);

        By employeeIdInput = By.xpath("//label[normalize-space()='Employee Id']/ancestor::div[contains(@class,'oxd-input-group')]//input");
        String employeeId = WaitUtils.waitForVisibility(employeeIdInput).getAttribute("value");

        WaitUtils.waitForClickable(SAVE_BUTTON).click();
        waitForEmployeeCreationLanding();

        this.lastAddedEmployeeName = firstName + " " + lastName;
        return employeeId;
    }

    public String getLastAddedEmployeeName() {
        return lastAddedEmployeeName;
    }

    public PimPage goToEmployeeList() {
        WaitUtils.waitForClickable(PIM_MENU).click();
        WaitUtils.waitForClickable(EMPLOYEE_LIST_TAB).click();
        return this;
    }

    public PimPage searchByEmployeeId(String employeeId) {
        By employeeIdSearchInput = By.xpath("(//label[normalize-space()='Employee Id']/ancestor::div[contains(@class,'oxd-input-group')]//input)[1]");
        WebElement input = WaitUtils.waitForVisibility(employeeIdSearchInput);
        input.clear();
        input.sendKeys(employeeId);
        WaitUtils.waitForClickable(SEARCH_BUTTON).click();
        return this;
    }

    public boolean isEmployeePresentInResults(String employeeId) {
        By employeeIdCell = By.xpath("//div[contains(@class,'oxd-table-cell')]/div[normalize-space()='" + employeeId + "']");
        try {
            return WaitUtils.waitForVisibility(employeeIdCell).isDisplayed();
        } catch (TimeoutException exception) {
            return false;
        }
    }

    private void waitForEmployeeCreationLanding() {
        try {
            WaitUtils.waitForVisibility(PERSONAL_DETAILS_HEADER);
            return;
        } catch (TimeoutException ignored) {
            // Continue with URL-based fallback.
        }

        WaitUtils.waitForUrlContains("/pim/viewPersonalDetails");
    }
}
