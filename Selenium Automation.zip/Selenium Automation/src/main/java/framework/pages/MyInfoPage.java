package framework.pages;

import framework.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;

public class MyInfoPage {
    private final WebDriver driver;

    private static final By MY_INFO_MENU = By.xpath("//span[normalize-space()='My Info']");
    private static final By PERSONAL_DETAILS_HEADER = By.xpath("//h6[normalize-space()='Personal Details']");

    public MyInfoPage(WebDriver driver) {
        this.driver = driver;
    }

    public MyInfoPage open() {
        WaitUtils.waitForClickable(MY_INFO_MENU).click();
        WaitUtils.waitForUrlContains("/pim/viewPersonalDetails");
        return this;
    }

    public boolean isMyInfoVisible() {
        try {
            return WaitUtils.waitForVisibility(PERSONAL_DETAILS_HEADER).isDisplayed();
        } catch (TimeoutException exception) {
            return false;
        }
    }
}
