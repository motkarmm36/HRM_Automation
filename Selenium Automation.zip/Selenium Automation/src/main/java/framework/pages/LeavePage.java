package framework.pages;

import framework.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;

public class LeavePage {
    private final WebDriver driver;

    private static final By LEAVE_MENU = By.xpath("//span[normalize-space()='Leave']");
    private static final By SEARCH_BUTTON = By.xpath("//button[@type='submit' and normalize-space()='Search']");
    private static final By APPLY_BUTTON = By.xpath("//button[@type='submit' and normalize-space()='Apply']");
    private static final By LEAVE_TABLE = By.cssSelector(".oxd-table-body");
    private static final By APPLY_TAB = By.xpath("//a[normalize-space()='Apply']");
    private static final By MY_LEAVE_TAB = By.xpath("//a[normalize-space()='My Leave']");
    private static final By COMMENT_TEXTAREA = By.xpath("//textarea");
    private static final By SUCCESS_TOAST = By.xpath("//div[contains(@class,'oxd-toast--success')]");
    private static final By WARNING_TOAST = By.xpath("//div[contains(@class,'oxd-toast--warn')]");
    private static final By ERROR_TOAST = By.xpath("//div[contains(@class,'oxd-toast--error')]");

    public LeavePage(WebDriver driver) {
        this.driver = driver;
    }

    public LeavePage open() {
        WaitUtils.waitForClickable(LEAVE_MENU).click();
        WaitUtils.waitForUrlContains("/leave");
        return this;
    }

    public LeavePage searchLeaveList() {
        WaitUtils.waitForClickable(SEARCH_BUTTON).click();
        return this;
    }

    public boolean isLeaveListRendered() {
        try {
            return WaitUtils.waitForVisibility(LEAVE_TABLE).isDisplayed();
        } catch (TimeoutException exception) {
            By noRecords = By.xpath("//span[normalize-space()='No Records Found']");
            return !driver.findElements(noRecords).isEmpty();
        }
    }

    public LeavePage applyLeave(String comment) {
        WaitUtils.waitForClickable(APPLY_TAB).click();
        selectFirstAvailableLeaveType();
        WaitUtils.waitForVisibility(COMMENT_TEXTAREA).sendKeys(comment);
        WaitUtils.waitForClickable(APPLY_BUTTON).click();
        return this;
    }

    public boolean isLeaveApplyAttemptProcessed() {
        try {
            return WaitUtils.waitForVisibility(SUCCESS_TOAST).isDisplayed();
        } catch (TimeoutException exception) {
            try {
                return WaitUtils.waitForVisibility(WARNING_TOAST).isDisplayed();
            } catch (TimeoutException innerException) {
                try {
                    return WaitUtils.waitForVisibility(ERROR_TOAST).isDisplayed();
                } catch (TimeoutException finalException) {
                    return driver.getCurrentUrl().contains("/leave");
                }
            }
        }
    }

    public LeavePage openMyLeaveAndSearch() {
        WaitUtils.waitForClickable(MY_LEAVE_TAB).click();
        WaitUtils.waitForClickable(SEARCH_BUTTON).click();
        return this;
    }

    public boolean isOnMyLeavePage() {
        try {
            return WaitUtils.waitForUrlContains("/viewMyLeaveList");
        } catch (TimeoutException exception) {
            return false;
        }
    }

    private void selectFirstAvailableLeaveType() {
        By leaveTypeDropdown = By.xpath("//label[normalize-space()='Leave Type']/ancestor::div[contains(@class,'oxd-input-group')]//div[contains(@class,'oxd-select-text-input')]");
        WaitUtils.waitForClickable(leaveTypeDropdown).click();
        By firstOption = By.xpath("(//div[@role='listbox']//span[normalize-space()!='-- Select --'])[1]");
        WaitUtils.waitForClickable(firstOption).click();
    }
}
