package framework.pages;

import framework.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DashboardPage {
    private final WebDriver driver;

    private static final By DASHBOARD_HEADER = By.xpath("//h6[normalize-space()='Dashboard']");
    private static final By USER_DROPDOWN = By.cssSelector(".oxd-userdropdown-name");
    private static final By LOGOUT_LINK = By.xpath("//a[normalize-space()='Logout']");

    public DashboardPage(WebDriver driver) {
        this.driver = driver;
    }

    public DashboardPage waitUntilLoaded() {
        WaitUtils.waitForUrlContains("/dashboard");
        WaitUtils.waitForVisibility(DASHBOARD_HEADER);
        return this;
    }

    public boolean isLoaded() {
        return WaitUtils.waitForVisibility(DASHBOARD_HEADER).isDisplayed();
    }

    public LoginPage logout() {
        WaitUtils.waitForClickable(USER_DROPDOWN).click();
        WaitUtils.waitForClickable(LOGOUT_LINK).click();
        return new LoginPage(driver);
    }
}
